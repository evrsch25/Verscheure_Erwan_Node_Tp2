const express = require('express');
const app = express();
const port = 3000;

// Middleware pour afficher l'heure de l'appel de chaque route
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}]: ${req.method} ${req.originalUrl}`);
  next();
});

// Middleware pour gérer les routes non supportées
app.use((req, res, next) => {
  res.status(404).send("Cette page n'existe pas!");
});

// Route GET /
app.get('/', (req, res) => {
  res.send('Hello World!');
});

// Route GET /welcome
app.get('/welcome', (req, res) => {
  res.send('Bienvenue sur le TP 1 du cours d\'architecture logicielle');
});

// Route GET /users/:name
app.get('/users/:name', (req, res) => {
  const name = req.params.name;
  res.send(`Bienvenue sur la page de ${name}`);
});

// Route GET /somme
app.get('/somme', (req, res) => {
  const a = parseInt(req.query.a);
  const b = parseInt(req.query.b);
  const result = a + b;
  res.send(`La somme de ${a} et ${b} est ${result}`);
});

// Route GET /secret
app.get('/secret', (req, res) => {
  res.status(401).send('Vous ne possédez pas les droits pour accéder à ma page secrète');
});

// Route GET /error
app.get('/error', (req, res) => {
  res.status(500).json({ message: 'Une erreur interne est survenue.' });
});

// Route GET /img
app.get('/img', (req, res) => {
  const imagePath = './vfournier.jpg';
  res.sendFile(imagePath);
});

// Route GET /redirectMe
app.get('/redirectMe', (req, res) => {
  res.redirect('https://iut-littoral.fr/');
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
