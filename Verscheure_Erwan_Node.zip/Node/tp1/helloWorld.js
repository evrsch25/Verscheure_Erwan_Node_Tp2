// helloWorld.js

console.log("Hello World");
