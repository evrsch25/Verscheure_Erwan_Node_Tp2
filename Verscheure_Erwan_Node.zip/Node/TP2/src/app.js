// app.js

const express = require('express')
const app = express()
const { connectTodB } = require('./services/db/connexion.js');
const { createUser } = require('./controllers/users.js'); 
const port = 3000

app.use(express.json());

app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.post('/users/create', createUser);

app.listen(port, () => {
  connectTodB(),
  console.log(`Example app listening on port ${port}`)
})