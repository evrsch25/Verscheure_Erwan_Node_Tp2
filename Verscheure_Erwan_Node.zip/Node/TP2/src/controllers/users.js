const { insertOne } = require("../services/db/crud");

async function createUser(req, res) {
    const resultatRequete = req.body;
    const collection = "users";
    const result = await insertOne(collection, resultatRequete);
    return res.status(201).send(result);
}

module.exports = { createUser };